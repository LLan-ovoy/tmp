"""
A hashtable represented as a list of lists with open hashing.
Each bucket is a list of (key,value) tuples
"""

def htable(nbuckets):
    """Return a list of nbuckets lists"""
    table = []
    for i in range(nbuckets):
        table.append([])
    return table


def hashcode(o):
    """
    Return a hashcode for strings and integers; all others return None
    For integers, just return the integer value.
    For strings, perform operation h = h*31 + ord(c) for all characters in the string
    """
    if type(o) == str:
        hcode = 0
        for c in o:
            hcode = hcode * 31 + ord(c)
    elif type(o) == int:
        hcode = o
    else:
        hcode = None
    return hcode


def bucket_indexof(table, key):
    """
    You don't have to implement this, but I found it to be a handy function.
    Return the index of the element within a specific bucket; the bucket is:
    table[hashcode(key) % len(table)]. You have to linearly
    search the bucket to find the tuple containing key.
    """
    buck_idx = hashcode(key) % len(table)
    bucket = table[buck_idx]
    for i in range(len(bucket)):
        if bucket[i][0] == key:
            ele_idx = i
    return ele_idx


def htable_put(table, key, value):
    """
    Perform the equivalent of table[key] = value
    Find the appropriate bucket indicated by key and then append (key,value)
    to that bucket if the (key,value) pair doesn't exist yet in that bucket.
    If the bucket for key already has a (key,value) pair with that key,
    then replace the tuple with the new (key,value).
    Make sure that you are only adding (key,value) associations to the buckets.
    The type(value) can be anything. Could be a set, list, number, string, anything!
    """
    buck_idx = hashcode(key) % len(table)
    bucket = table[buck_idx]
    exist_key = []
    exist_value = []
    for e in bucket:
        exist_key.append(e[0])
    if key in exist_key:
        key_idx = exist_key.index(key)
        bucket[key_idx] = (key,value)
    else:
        bucket.append((key,value))
    return table


def htable_get(table, key):
    """
    Return the equivalent of table[key].
    Find the appropriate bucket indicated by the key and look for the
    association with the key. Return the value (not the key and not
    the association!). Return None if key not found.
    """
    buck_idx = hashcode(key) % len(table)
    bucket = table[buck_idx]
    exist_key = []
    for e in bucket:
        exist_key.append(e[0])
    if key in exist_key:
        key_idx = exist_key.index(key)
        key_value = bucket[key_idx][1]
    else:
        key_value = None
    return key_value

def htable_buckets_str(table):
    """
    Return a string representing the various buckets of this table.
    The output looks like:
        0000->
        0001->
        0002->
        0003->parrt:99
        0004->
    where parrt:99 indicates an association of (parrt,99) in bucket 3.
    """
    cont = []
    for i in range(0,len(table)):
        cont.append('000'+str(i)+"->")
        elem = []
        for j in range(len(table[i])):
            elem.append(str(table[i][j][0])+':'+str(table[i][j][1]))
        cont[i] = cont[i]+ ", ".join(elem)+'\n'
    hostr = ''.join(cont)
    return hostr

def htable_str(table):
    """
    Return what str(table) would return for a regular Python dict
    such as {parrt:99}. The order should be in bucket order and then
    insertion order within each bucket. The insertion order is
    guaranteed when you append to the buckets in htable_put().
    """
    cont = []
    for i in range(len(table)):
        for j in range(len(table[i])):
            cont.append(str(table[i][j][0])+":"+str(table[i][j][1]))
    hstr = "{" + ", ".join(cont) + "}"
    return hstr
