from collections import defaultdict  # https://docs.python.org/2/library/collections.html

from words import get_text, words


def create_index(files):
    """
    Given a list of fully-qualified filenames, build an index from word
    to set of document IDs. A document ID is just the index into the
    files parameter (indexed from 0) to get the file name. Make sure that
    you are mapping a word to a set of doc IDs, not a list.
    For each word w in file i, add i to the set of document IDs containing w
    Return a dict object mapping a word to a set of doc IDs.
    """
    fileind = []
    for i in range(len(files)):
        fileind.append((i, files[i]))
    index = {}
    for filename in fileind:
        text = get_text(filename[1])
        corpus = words(text)
        for c in corpus:
            if (c in index.keys()):
                if (filename[0] not in index[c]):
                    index[c].append(filename[0])
            else:
                index[c] = [filename[0]]
    return index

def index_search(files, index, terms):
    """
    Given an index and a list of fully-qualified filenames, return a list of
    filenames whose file contents has all words in terms parameter as normalized
    by your words() function.  Parameter terms is a list of strings.
    You can only use the index to find matching files; you cannot open the files
    and look inside.
    """
    fileind = []
    for i in range(len(files)):
        fileind.append((i, files[i]))

    inters = []
    for t in terms:
        if t in index.keys():
            pmatch = index[t]
        else:
            pmatch = []
        inters.extend(pmatch)

    matches = []
    for i in range(len(files)):
        count = inters.count(i)
        if count == len(terms):
            matches.append(fileind[i][1])
    return matches
