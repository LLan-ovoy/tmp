# Got slate magazine data from http://www.anc.org/data/oanc/contents/
# rm'd .xml, .anc files, leaving just .txt
# 4534 files in like 55 subdirs

from words import get_text, words

def linear_search(files, terms):
    matches = []
    for filename in files:
        text = get_text(filename)
        corpus = words(text)
        count = 0
        for t in terms:
            if t in corpus:
                count += 1
        if count == len(terms):
            matches.append(filename)
    return matches
