"""
A hashtable represented as a list of lists with open hashing.
Each bucket is a list of (key,value) tuples
"""


class HashTable():
    def __init__(self, nbuckets):
        self.nbuckets = nbuckets
        self.table = [[] for i in range(nbuckets)]

    def __len__(self):
        return sum(len(i) for i in self.table)

    def if_exist(self, key):
        bucket = self.table[hash(key) % self.nbuckets]
        for i in range(len(bucket)):
            if bucket[i][0] == key:
                return i
        return None

    def __contains__(self, key):
        bucket = self.table[hash(key) % self.nbuckets]
        for i in range(len(bucket)):
            if bucket[i][0] == key:
                return True
        return False

    def __setitem__(self, key, value):
        bucket = self.table[hash(key) % self.nbuckets]
        exist = self.if_exist(key)
        if exist is None:
            bucket.append((key, value))
        else:
            bucket[exist] = (key, value)

    def __getitem__(self, key):
        bucket = self.table[hash(key) % self.nbuckets]
        exist = self.if_exist(key)
        if exist is not None:
            return bucket[exist][1]
        return None

    def __iter__(self):
        return iter(self.keys())

    def keys(self):
        keys = []
        for bucket in self.table:
            key_t = [e[0] for e in bucket]
            keys = keys + key_t
        return keys

    def items(self):
        items = []
        for key in self.keys():
            value = self.__getitem__(key)
            items.append((key, value))
        return items

    def __repr__(self):
        return self.__str__()

    def __str__(self):
        pairs = []
        for i in range(self.nbuckets):
            for key, value in enumerate(self.table[i]):
                pairs.append(f"{value[0]}:{value[1]}")
        return '{' + ", ".join(pairs) + '}'
